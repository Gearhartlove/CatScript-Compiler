package edu.montana.csci.csci468.bytecode;

import edu.montana.csci.csci468.eval.CatscriptRuntime;
import edu.montana.csci.csci468.parser.statements.CatScriptProgram;

public class JVMCatScriptProgram extends CatScriptProgram {
    @Override
    public void execute(CatscriptRuntime runtime) {
    }
}
