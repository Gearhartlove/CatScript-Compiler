package edu.montana.csci.csci468.demo;

public class BytecodeDemo {

//    int add(int i) {
//        return i + 13;
//    }
    void foo() {
        int x = 1;
        if (x > 1) {
            System.out.println("Greater");
        } else {
            System.out.println("Less");
        }
    }
}
